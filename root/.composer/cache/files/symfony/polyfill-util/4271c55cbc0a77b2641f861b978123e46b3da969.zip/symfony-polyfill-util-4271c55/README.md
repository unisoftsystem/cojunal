Symfony Polyfill / Util
=======================

This component provides binary-safe string functions, using the 
[mbstring](https://php.net/mbstring) extension when available.

More information can be found in the 
[main Polyfill README](https://github.com/symfony/polyfill/blob/master/README.md).

License
=======

This library is released under the [MIT license](LICENSE).